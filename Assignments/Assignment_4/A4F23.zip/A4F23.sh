#!/bin/bash

tarFileNumber=1
ibFileNumber=1
myUserName=$USER

mkdir -p "$HOME/home/backup/cb" #Creating the backup cb folder if not present
mkdir -p "$HOME/home/backup/ib" #Creating the backup ib folder if not present

while true; do
    currentStartTime=$(date +"%a %d %b %Y %I:%M:%S %p %Z") # Storing the current time
    currentTime=$(date +"%a %d %b %Y %I:%M:%S %p %Z") # Storing the current time
    tarFileNameForBackup="cb0000${tarFileNumber}.tar" # Storing the tar file name
    # Below is the command to find the files with .c and .txt and creating the tar
    find /home/${myUserName} -type f \( -name "*.c" -o -name "*.txt" \) -exec tar -rvf ~/home/backup/cb/${tarFileNameForBackup} {} +
    # Storing the update in the backup.log
    echo "${currentStartTime} - ${tarFileNameForBackup}" >> ~/home/backup/backup.log
    tarFileNumber=$((tarFileNumber + 1)) # Increasing the tar file number


    # Waiting for 2 minutes for the next backup check
    sleep 120

    currentStartTime=$(date +"%a %d %b %Y %I:%M:%S %p %Z") # Storing the current time
    # Below is the command to find the modified files with .c and .txt after the first backup
    modifiedFiles=$(find /home/${myUserName} -type f \( -name "*.c" -o -name "*.txt" \) -newermt "${currentTime}")

    # If any file is found then
    if [ -n "$modifiedFiles" ]; then
        incrementFileName="ib1000${ibFileNumber}.tar" # ib file name
        # Below is the command to find the modified files with .c and .txt after the first backup and creating the tar
        find /home/${myUserName} -type f \( -name "*.c" -o -name "*.txt" \) -newermt "${currentTime}" -exec tar -czf "$HOME/home/backup/ib/${incrementFileName}" {} +
        # Storing the update in the backup.log
        echo "${currentStartTime} - ${incrementFileName}" >> ~/home/backup/backup.log
        ibFileNumber=$((ibFileNumber + 1)) # Increasing the ib file number
    else
        # Storing that no files modified in the backup.log
        echo "${currentStartTime} - No changes-Incremental backup was not created." >> ~/home/backup/backup.log
    fi
    currentTime=$(date +"%a %d %b %Y %I:%M:%S %p %Z")
    
    # Waiting for 2 minutes for the next backup check
    sleep 120

    currentStartTime=$(date +"%a %d %b %Y %I:%M:%S %p %Z") # Storing the current time
    # Below is the command to find the modified files with .c and .txt after the first backup
    modifiedFiles=$(find /home/${myUserName} -type f \( -name "*.c" -o -name "*.txt" \) -newermt "${currentTime}")

    # If any file is found then
    if [ -n "$modifiedFiles" ]; then
        incrementFileName="ib1000${ibFileNumber}.tar" # ib file name
        # Below is the command to find the modified files with .c and .txt after the first backup and creating the tar
        find /home/${myUserName} -type f \( -name "*.c" -o -name "*.txt" \) -newermt "${currentTime}" -exec tar -czf "$HOME/home/backup/ib/${incrementFileName}" {} +
        # Storing the update in the backup.log
        echo "${currentStartTime} - ${incrementFileName}" >> ~/home/backup/backup.log
        ibFileNumber=$((ibFileNumber + 1)) # Increasing the ib file number
    else
        # Storing that no files modified in the backup.log
        echo "${currentStartTime} - No changes-Incremental backup was not created." >> ~/home/backup/backup.log
    fi
    currentTime=$(date +"%a %d %b %Y %I:%M:%S %p %Z")
    
    # Waiting for 2 minutes for the next backup check
    sleep 120

    currentStartTime=$(date +"%a %d %b %Y %I:%M:%S %p %Z") # Storing the current time
    # Below is the command to find the modified files with .c and .txt after the first backup
    modifiedFiles=$(find /home/${myUserName} -type f \( -name "*.c" -o -name "*.txt" \) -newermt "${currentTime}")

    # If any file is found then
    if [ -n "$modifiedFiles" ]; then
        incrementFileName="ib1000${ibFileNumber}.tar" # ib file name
        # Below is the command to find the modified files with .c and .txt after the first backup and creating the tar
        find /home/${myUserName} -type f \( -name "*.c" -o -name "*.txt" \) -newermt "${currentTime}" -exec tar -czf "$HOME/home/backup/ib/${incrementFileName}" {} +
        # Storing the update in the backup.log
        echo "${currentStartTime} - ${incrementFileName}" >> ~/home/backup/backup.log
        ibFileNumber=$((ibFileNumber + 1)) # Increasing the ib file number
    else
        # Storing that no files modified in the backup.log
        echo "${currentStartTime} - No changes-Incremental backup was not created." >> ~/home/backup/backup.log
    fi
    currentTime=$(date +"%a %d %b %Y %I:%M:%S %p %Z")
    
    # Waiting for 2 minutes for the next backup check
    sleep 120
done &