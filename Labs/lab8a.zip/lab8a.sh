#!/bin/bash

karanFileName="sample.txt"

if [ -e $karanFileName ]; then
    if [ ! -O $karanFileName ]; then
    echo "I am not the owner of the file" # If the current user is not the owner
    else
        if [ -w $karanFileName ]; then
        echo "Appending the content of ls -1 into the sample.txt"
        ls -1 >> $karanFileName
        else
        echo "Giving the write permission to the file"
        chmod +w $karanFileName #providing the write permission
        fi
    fi
else
    echo "File not present, creating the new file"
    touch $karanFileName #Creating the new file sample.txt
fi    