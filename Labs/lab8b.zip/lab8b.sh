#!/bin/bash

totalArguments=$# #total arguments
directoryToSearch=$1 # argument 1
extensionProvided=$2 # argument 2

if [ "$#" -lt 1 ]; then # If the syntax is wrong
    echo "Usage: $0 <directory_path> [file_extension]"
    exit 1
fi

if [ ! -d "$directoryToSearch" ]; then # if the dir is not present throw error
    echo "Error: Not able to find the Directory '$directoryToSearch'."
    exit 1
fi

if [ -z "$extensionProvided" ]; then # if the extension is not provided then take everything
    extensionProvided=".*"
    file_count=$(find "$directoryToSearch" -type f | wc -l) # command to find the total files
    echo "Total Number of files in $directoryToSearch: $file_count"
else
    # if the extension is given
    file_count=$(find "$directoryToSearch" -type f -name "*$extensionProvided" | wc -l) #command to find the total files with extension
    echo "Number of $extensionProvided files in $directoryToSearch is :$file_count"
fi