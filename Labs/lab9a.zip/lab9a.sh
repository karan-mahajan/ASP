#!/bin/bash

valid_files=() # creating an array to store the files


if [ "$#" -lt 1 ] || [ "$#" -ge 5 ]; then # Checking the usage of the command
    echo "Usage: $0 filename1 filename2 filename3 filename4"
    exit 1
fi

until [ -z "$1" ]; do # checking the each argument with the conditions
    if [ ! -e "$1" ]; then # checking if the given file name exists or not
        echo "'$1' file not exists"
        exit 1
    fi

    if [ "${1##*.}" != "txt" ]; then     # checking if the given file has a txt extension
        echo "'$1' is not with .txt extension"
        exit 1
    fi

    valid_files+=("$1") # adding the validated files into the array
    shift # going to the next argument
done


reverse_order=( $(for i in "${valid_files[@]}"; do echo "$i"; done | tac) ) # reversing the values of the array

cat "${reverse_order[@]}" > result.txt # concatinating the values of the file into the result.txt

echo "Successfully concatinated the files into result.txt"
